SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_administrador`;

CREATE TABLE `tb_administrador` (
  `id_administrador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_administrador` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_administrador` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_administrador` int(11) DEFAULT NULL,
  `user_admin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `password_admin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_admin` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion_admin` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_administrador`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_administrador` VALUES (1,"Admin","administrador",67676787,"admin123","admin123","Activo","Es el administrador del sistema");


DROP TABLE IF EXISTS `tb_almacen`;

CREATE TABLE `tb_almacen` (
  `id_almacen` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_almacen` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_almacen`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_almacen` VALUES (1,"ALMACEN PRINCIPAL",1,"2025-12-27 23:40:00","Activo",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_categoria`;

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_cat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cierre_caja`;

CREATE TABLE `tb_cierre_caja` (
  `id_cierre_caja` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_venta_cierre` decimal(30,2) DEFAULT NULL,
  `monto_caja` decimal(30,2) DEFAULT NULL,
  `monto_sobrante` decimal(30,2) DEFAULT NULL,
  `cantidad_ventas` int(11) DEFAULT NULL,
  `codigos_ventas` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `cantidad_productos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cierre_caja_venta`;

CREATE TABLE `tb_cierre_caja_venta` (
  `id_cierre_caja_venta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cierre_caja` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `fecha_accion` date DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_admin_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_cliente`;

CREATE TABLE `tb_cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_cliente` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_cliente` int(11) DEFAULT NULL,
  `estado_cliente` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_cliente` VALUES (1,"CLIENTE 1","APELLIDO 1",776567665,"Activo",""),
(2,"CLIENTE 2 ","AP 2",7,"Activo","");


DROP TABLE IF EXISTS `tb_compra`;

CREATE TABLE `tb_compra` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_compra` datetime DEFAULT NULL,
  `monto_compra` decimal(30,2) DEFAULT NULL,
  `compra_facturada` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `costo_factura` decimal(30,2) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `compra_credito` int(11) DEFAULT NULL,
  `cancelado` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_compra` VALUES (1,"2025-12-27 23:42:00","70.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(2,"2025-12-27 23:43:00","150.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(3,"2026-01-04 17:44:00","150.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(6,"2026-02-02 02:04:00","300.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(7,"2026-02-02 20:55:00","1400.00","no","0.00",1,1,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(8,"2026-02-02 22:03:00","1100.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(9,"2026-02-02 22:25:00","144.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(10,"2026-02-02 23:06:00","577.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(11,"2026-02-02 23:25:00","500.00","no","0.00",1,0,1,0,"Activo","admin",0,"0000-00-00 00:00:00"),
(12,"2026-02-02 23:29:00","600.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(13,"2026-02-02 23:40:00","500.00","no","0.00",1,0,1,0,"Activo","admin",0,"0000-00-00 00:00:00"),
(14,"2026-02-02 23:47:00","300.00","no","0.00",1,2,1,0,"Activo","admin",0,"0000-00-00 00:00:00"),
(15,"2026-02-02 23:55:00","800.00","no","0.00",1,3,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(16,"2026-02-02 23:58:00","400.00","no","0.00",1,2,1,0,"Activo","admin",0,"0000-00-00 00:00:00"),
(17,"2026-02-07 12:13:00","1450.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(18,"2026-02-07 12:20:00","345.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(19,"2026-02-07 12:26:00","1000.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(20,"2026-02-07 12:42:00","750.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(21,"2026-02-07 14:44:00","1700.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(22,"2026-02-07 14:44:00","600.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(23,"2026-02-07 14:46:00","1055.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(24,"2026-02-07 14:48:00","1055.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(25,"2026-02-07 15:02:00","4200.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(26,"2026-02-07 15:04:00","1800.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(27,"2026-02-07 15:05:00","755.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(28,"2026-02-07 15:05:00","3400.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(29,"2026-02-07 15:13:00","1266.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(30,"2026-02-07 15:13:00","1266.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(31,"2026-02-07 15:14:00","1899.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(32,"2026-02-07 15:16:00","1110.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(33,"2026-02-07 16:15:00","1700.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(34,"2026-02-07 16:17:00","2600.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(35,"2026-02-07 16:21:00","11000.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(36,"2026-02-07 16:22:00","600.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(37,"2026-02-07 16:23:00","6000.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(38,"2026-02-08 00:39:00","1500.00","no","0.00",1,0,1,0,"Activo","admin",0,"0000-00-00 00:00:00"),
(39,"2026-02-08 00:46:00","7700.00","no","0.00",1,0,1,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(40,"2026-02-08 00:47:00","2000.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(41,"2026-02-08 16:04:00","1300.00","no","0.00",1,2,1,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(42,"2026-02-08 16:52:00","1100.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(43,"2026-02-08 16:54:00","1200.00","no","0.00",1,3,1,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(44,"2026-02-08 23:30:00","1900.00","no","0.00",1,0,0,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(45,"2026-02-08 23:50:00","80.00","no","0.00",1,0,0,1,"Inactivo","admin",1,"2026-02-08 23:52:00");


DROP TABLE IF EXISTS `tb_compra_producto`;

CREATE TABLE `tb_compra_producto` (
  `id_compra_producto` int(11) NOT NULL AUTO_INCREMENT,
  `subtotal_compra` decimal(30,2) DEFAULT NULL,
  `cantidad_compra` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `precio_unit_compra` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_unit_compraFacturado` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod_Fact` decimal(30,2) DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `precio_tope` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_compra_producto`),
  KEY `id_compra` (`id_compra`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tb_compra_producto_ibfk_1` FOREIGN KEY (`id_compra`) REFERENCES `tb_compra` (`id_compra`),
  CONSTRAINT `tb_compra_producto_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `tb_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_compra_producto` VALUES (1,"70.00",50,1,2,"1.4","0.00","2.00","2.00",10,"2.00","Activo"),
(2,"150.00",80,2,1,"1.875","0.00","2.50","2.50",75,"2.50","Activo"),
(3,"150.00",100,3,2,"1.5","0.00","2.00","2.00",25,"2.00","Activo"),
(4,"200.00",20,6,2,"10.00","0.00","15.00","15.00",15,"15.00","Activo"),
(5,"100.00",50,6,3,"2.00","0.00","4.00","4.00",50,"4.00","Activo"),
(6,"400.00",200,7,2,"2.00","0.00","3.00","3.00",180,"3.00","Activo"),
(7,"1000.00",500,7,4,"2.00","0.00","3.00","3.00",500,"3.00","Activo"),
(8,"500.00",20,8,2,"25.00","0.00","30.00","30.00",20,"30.00","Activo"),
(9,"600.00",400,8,4,"1.50","0.00","3.00","3.00",400,"3.00","Activo"),
(10,"89.00",39,9,2,"2.28","0.00","3.00","3.00",39,"3.00","Activo"),
(11,"55.00",4,9,3,"13.75","0.00","23.00","23.00",4,"23.00","Activo"),
(12,"577.00",33,10,5,"17.48","0.00","0.00","0.00",33,"0.00","Activo"),
(13,"500.00",200,11,2,"2.50","0.00","5.00","5.00",200,"5.00","Activo"),
(14,"600.00",300,12,5,"2.00","0.00","4.00","4.00",300,"4.00","Activo"),
(15,"500.00",200,13,3,"2.50","0.00","5.00","5.00",200,"5.00","Activo"),
(16,"300.00",200,14,5,"1.50","0.00","0.00","0.00",200,"0.00","Activo"),
(17,"800.00",200,15,1,"4.00","0.00","5.00","5.00",200,"5.00","Activo"),
(18,"400.00",500,16,3,"0.80","0.00","2.50","2.50",500,"2.50","Activo"),
(19,"650.00",100,17,5,"6.50","0.00","7.00","7.00",100,"7.00","Activo"),
(20,"300.00",700,17,1,"0.43","0.00","1.00","1.00",700,"1.00","Activo"),
(21,"500.00",800,17,3,"0.63","0.00","1.00","1.00",800,"1.00","Activo"),
(22,"45.00",45,18,3,"1.00","0.00","2.00","2.00",45,"2.00","Activo"),
(23,"300.00",50,18,4,"6.00","0.00","7.00","7.00",50,"7.00","Activo"),
(24,"600.00",500,19,3,"1.20","0.00","2.00","2.00",500,"2.00","Activo"),
(25,"400.00",100,19,5,"4.00","0.00","5.00","5.00",100,"5.00","Activo"),
(26,"600.00",300,20,2,"2.00","0.00","3.00","3.00",300,"3.00","Activo"),
(27,"150.00",500,20,3,"0.30","0.00","3.00","3.00",500,"3.00","Activo"),
(28,"800.00",400,21,2,"2.00","0.00","3.00","3.00",400,"3.00","Activo"),
(29,"900.00",600,21,3,"1.50","0.00","3.00","3.00",600,"3.00","Activo"),
(30,"600.00",600,22,1,"1.00","0.00","2.00","2.00",600,"2.00","Activo"),
(31,"600.00",500,23,3,"1.20","0.00","3.00","3.00",500,"3.00","Activo"),
(32,"455.00",900,23,1,"0.51","0.00","5.00","5.00",900,"5.00","Activo"),
(33,"3000.00",800,25,3,"3.75","0.00","5.00","5.00",800,"5.00","Activo"),
(34,"1200.00",600,25,4,"2.00","0.00","3.00","3.00",600,"3.00","Activo"),
(35,"1200.00",900,26,3,"1.33","0.00","3.00","3.00",900,"3.00","Activo"),
(36,"600.00",200,26,5,"3.00","0.00","4.00","4.00",200,"4.00","Activo"),
(37,"555.00",600,27,5,"0.93","0.00","1.00","1.00",600,"1.00","Activo"),
(38,"200.00",800,27,3,"0.25","0.00","1.00","1.00",800,"1.00","Activo"),
(39,"2000.00",900,28,5,"2.22","0.00","3.00","3.00",900,"3.00","Activo"),
(40,"600.00",100,28,1,"6.00","0.00","7.00","7.00",100,"7.00","Activo"),
(41,"800.00",200,28,3,"4.00","0.00","5.00","5.00",200,"5.00","Activo"),
(42,"599.00",55,29,2,"10.89","0.00","55.00","55.00",55,"55.00","Activo"),
(43,"667.00",55,29,4,"12.13","0.00","55.00","55.00",55,"55.00","Activo"),
(44,"999.00",900,31,2,"1.11","0.00","3.00","3.00",900,"3.00","Activo"),
(45,"900.00",88,31,4,"10.23","0.00","12.00","12.00",88,"12.00","Activo"),
(46,"555.00",55,32,4,"10.09","0.00","55.00","55.00",55,"55.00","Activo"),
(47,"555.00",55,32,3,"10.09","0.00","55.00","55.00",55,"55.00","Activo"),
(48,"900.00",600,33,2,"1.50","0.00","5.00","5.00",600,"5.00","Activo"),
(49,"800.00",700,33,4,"1.14","0.00","5.00","5.00",700,"5.00","Activo"),
(50,"900.00",900,34,3,"1.00","0.00","2.00","2.00",900,"2.00","Activo"),
(51,"800.00",400,34,2,"2.00","0.00","3.00","3.00",400,"3.00","Activo"),
(52,"900.00",1000,34,5,"0.90","0.00","1.00","1.00",1000,"1.00","Activo"),
(53,"4000.00",1000,35,2,"4.00","0.00","5.00","5.00",1000,"5.00","Activo"),
(54,"7000.00",500,35,3,"14.00","0.00","20.00","20.00",500,"20.00","Activo"),
(55,"600.00",800,36,3,"0.75","0.00","1.00","1.00",800,"1.00","Activo"),
(56,"2000.00",800,37,3,"2.50","0.00","5.00","5.00",800,"5.00","Activo"),
(57,"4000.00",400,37,4,"10.00","0.00","15.00","15.00",400,"15.00","Activo"),
(58,"900.00",100,38,4,"9.00","0.00","10.00","10.00",100,"10.00","Activo"),
(59,"600.00",450,38,3,"1.33","0.00","2.00","2.00",450,"2.00","Activo"),
(60,"900.00",300,39,2,"3.00","0.00","4.00","4.00",300,"4.00","Activo"),
(61,"800.00",700,39,1,"1.14","0.00","3.00","3.00",700,"3.00","Activo"),
(62,"6000.00",600,39,5,"10.00","0.00","15.00","15.00",600,"15.00","Activo"),
(63,"2000.00",900,40,2,"2.22","0.00","4.00","4.00",900,"4.00","Activo"),
(64,"400.00",300,41,4,"1.33","0.00","6.00","6.00",300,"6.00","Activo"),
(65,"900.00",500,41,3,"1.80","0.00","5.00","5.00",500,"5.00","Activo"),
(66,"500.00",500,42,2,"1.00","0.00","2.00","2.00",500,"2.00","Activo"),
(67,"600.00",900,42,4,"0.67","0.00","9.00","9.00",900,"9.00","Activo"),
(68,"500.00",500,43,3,"1.00","0.00","2.00","2.00",500,"2.00","Activo"),
(69,"600.00",600,43,4,"1.00","0.00","2.00","2.00",600,"2.00","Activo"),
(70,"100.00",900,43,1,"0.11","0.00","1.00","1.00",900,"1.00","Activo"),
(71,"200.00",20,44,2,"10.00","0.00","20.00","20.00",20,"20.00","Activo"),
(72,"300.00",40,44,4,"7.50","0.00","10.00","10.00",40,"10.00","Activo"),
(73,"600.00",60,44,3,"10.00","0.00","20.00","20.00",55,"20.00","Activo"),
(74,"800.00",50,44,1,"16.00","0.00","20.00","20.00",50,"20.00","Activo"),
(75,"60.00",5,45,3,"12.00","0.00","15.00","15.00",5,"15.00","Inactivo"),
(76,"20.00",8,45,4,"2.50","0.00","5.00","5.00",8,"5.00","Inactivo");


DROP TABLE IF EXISTS `tb_cuota_compra`;

CREATE TABLE `tb_cuota_compra` (
  `id_cuota_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cuota` datetime DEFAULT NULL,
  `monto_cuota` decimal(30,2) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cuota_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_cuota_compra` VALUES (1,"2026-02-08 00:39:00","500.00",38,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(2,"2026-02-08 00:46:00","700.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(4,"2026-02-08 18:20:00","1000.00",43,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(5,"2026-02-08 18:22:00","300.00",41,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(6,"2026-02-08 18:23:00","500.00",41,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(7,"2026-02-08 18:28:00","500.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(8,"2026-02-08 18:30:00","3000.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(9,"2026-02-08 18:30:00","2000.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(10,"2026-02-08 18:34:00","500.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(11,"2026-02-08 18:35:00","500.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(12,"2026-02-08 18:35:00","500.00",39,1,"Activo","admin",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_cuota_venta`;

CREATE TABLE `tb_cuota_venta` (
  `id_cuota_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cuota` datetime DEFAULT NULL,
  `monto_cuota` decimal(30,2) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cuota_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_cuota_venta` VALUES (1,"2026-02-09 03:17:00","50.00",6,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(2,"2026-02-10 00:49:00","50.00",6,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(3,"2026-02-10 00:53:00","5.00",6,1,"Activo","admin",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_empleado`;

CREATE TABLE `tb_empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_empleado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_empleado` int(11) DEFAULT NULL,
  `user_name_emp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `password_emp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_empleado` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion_emp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `permiso_especial` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_marca`;

CREATE TABLE `tb_marca` (
  `id_marca` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_marca` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_marca` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_precio_factura`;

CREATE TABLE `tb_precio_factura` (
  `id_precio_factura` int(11) NOT NULL AUTO_INCREMENT,
  `porcentaje_p_nofacturado` int(11) DEFAULT NULL,
  `porcentaje_p_facturado` int(11) DEFAULT NULL,
  `id_administrador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_precio_factura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_producto`;

CREATE TABLE `tb_producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `codigo_producto` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `stok_facturado` int(11) DEFAULT NULL,
  `stock_simple` int(11) DEFAULT NULL,
  `estado_producto` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_marca` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `tipo_reg` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `id_almacen` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_producto` VALUES (1,"BOLSA QUINTALERA","","30CM X 90CM",0,0,"Activo",0,0,"admin",1,"2025-12-27 23:41:00",0,"0000-00-00 00:00:00","2025-12-27 23:41:00",1),
(2,"BOLSA ARROBA","","30CM X 50CM",0,0,"Activo",0,0,"admin",1,"2025-12-27 23:41:00",0,"0000-00-00 00:00:00","2025-12-27 23:41:00",1),
(3,"BOLSA BELEN","","5 KILOS",0,0,"Activo",0,0,"admin",1,"2026-01-17 23:48:00",0,"0000-00-00 00:00:00","2026-01-17 23:48:00",1),
(4,"BOLSA AZUL","","20X20",0,0,"Activo",0,0,"admin",1,"2026-01-17 23:54:00",0,"0000-00-00 00:00:00","2026-01-17 23:54:00",1),
(5,"BOLSA ROJA","","40X35",0,0,"Activo",0,0,"admin",1,"2026-01-17 23:55:00",0,"0000-00-00 00:00:00","2026-01-17 23:55:00",1);


DROP TABLE IF EXISTS `tb_proveedor`;

CREATE TABLE `tb_proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `apellido_proveedor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `telefono_proveedor` int(11) DEFAULT NULL,
  `estado_proveedor` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `observacion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_proveedor` VALUES (1,"PROVEEDOR 1","PERES",2147483647,"Activo",""),
(2,"PROVEEDOR 2","LOPEZ",786767565,"Activo",""),
(3,"PROVEEDOR  3","VARGAS",787665554,"Activo","VSRDFB");


DROP TABLE IF EXISTS `tb_sucursal`;

CREATE TABLE `tb_sucursal` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_suc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descripcion_suc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `contacto` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `estado_suc` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_envio`;

CREATE TABLE `tb_transferencia_stock_envio` (
  `id_transferencia_envio` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_transferencia_enviada` datetime DEFAULT NULL,
  `cantidad_envio` int(11) DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `descripcion_trans_envio` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `id_sucursal_destino` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_recibido`;

CREATE TABLE `tb_transferencia_stock_recibido` (
  `id_transferencia_recibido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_trn_recibido` datetime DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `cantidad_recibida` int(11) DEFAULT NULL,
  `estado_recibida` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion_recibido` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `id_sucursal_origen` int(11) DEFAULT NULL,
  `codigo_de_envio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_recibido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `tb_venta`;

CREATE TABLE `tb_venta` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime DEFAULT NULL,
  `monto_venta` decimal(30,2) DEFAULT NULL,
  `venta_facturada` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_facturaV` decimal(30,2) DEFAULT NULL,
  `tipo_venta` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `venta_credito` int(11) NOT NULL,
  `cancelado` int(11) NOT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_venta` VALUES (1,"2025-12-27 23:49:00","22.50","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00"),
(2,"2026-02-07 12:24:00","20.00","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00"),
(3,"2026-02-07 12:25:00","20.00","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00"),
(4,"2026-02-07 16:36:00","140.00","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00"),
(5,"2026-02-08 23:33:00","100.00","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00"),
(6,"2026-02-09 03:17:00","105.00","no","0.00","admin",1,1,1,"Activo",0,"0000-00-00 00:00:00"),
(7,"2026-02-09 23:37:00","82.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-09 23:44:00"),
(8,"2026-02-09 23:46:00","14.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-09 23:46:00"),
(9,"2026-02-09 23:49:00","10.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-09 23:49:00"),
(10,"2026-02-09 23:50:00","85.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-09 23:50:00"),
(11,"2026-02-10 00:01:00","20.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-10 00:01:00"),
(12,"2026-02-10 00:07:00","85.00","no","0.00","admin",1,0,1,"Inactivo",1,"2026-02-10 00:07:00"),
(13,"2026-02-10 00:07:00","70.00","no","0.00","admin",1,0,1,"Activo",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_venta_cliente`;

CREATE TABLE `tb_venta_cliente` (
  `id_venta_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_venta_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_cliente` (`id_cliente`),
  CONSTRAINT `tb_venta_cliente_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_venta_cliente` VALUES (1,1,13);


DROP TABLE IF EXISTS `tb_venta_producto`;

CREATE TABLE `tb_venta_producto` (
  `id_venta_producto` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_prod` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal_venta` decimal(30,2) DEFAULT NULL,
  `cantidad_prod` int(11) DEFAULT NULL,
  `ventaP_facturada` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precio_factura` decimal(30,2) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `precio_unitario_venta` decimal(30,2) DEFAULT NULL,
  `precio_compra_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_establecido` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_venta_producto`),
  KEY `id_compra_producto` (`id_compra_producto`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_producto_ibfk_1` FOREIGN KEY (`id_compra_producto`) REFERENCES `tb_compra_producto` (`id_compra_producto`),
  CONSTRAINT `tb_venta_producto_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_venta_producto` VALUES (1,"","10.00",5,0,"0.00",1,1,"2.00","1.40","2.00","Activo"),
(2,"","12.50",5,0,"0.00",2,1,"2.50","1.88","2.50","Activo"),
(3,"undefined","10.00",5,0,"0.00",3,2,"2.00","1.50","2.00","Activo"),
(4,"undefined","10.00",5,0,"0.00",1,2,"2.00","1.40","2.00","Activo"),
(5,"undefined","10.00",5,0,"0.00",1,3,"2.00","1.40","2.00","Activo"),
(6,"undefined","10.00",5,0,"0.00",3,3,"2.00","1.50","2.00","Activo"),
(7,"undefined","40.00",20,0,"0.00",1,4,"2.00","1.40","2.00","Activo"),
(8,"undefined","100.00",50,0,"0.00",3,4,"2.00","1.50","2.00","Activo"),
(9,"undefined","100.00",5,0,"0.00",73,5,"20.00","10.00","20.00","Activo"),
(10,"undefined","10.00",5,0,"0.00",1,6,"2.00","1.40","2.00","Activo"),
(11,"undefined","20.00",10,0,"0.00",3,6,"2.00","1.50","2.00","Activo"),
(12,"undefined","75.00",5,0,"0.00",4,6,"15.00","10.00","15.00","Activo"),
(13,"undefined","12.00",6,0,"0.00",1,7,"2.00","1.40","2.00","Inactivo"),
(14,"undefined","10.00",5,0,"0.00",3,7,"2.00","1.50","2.00","Inactivo"),
(15,"undefined","60.00",2,0,"0.00",8,7,"30.00","25.00","30.00","Inactivo"),
(16,"undefined","8.00",4,0,"0.00",1,8,"2.00","1.40","2.00","Inactivo"),
(17,"undefined","6.00",3,0,"0.00",3,8,"2.00","1.50","2.00","Inactivo"),
(18,"undefined","10.00",5,0,"0.00",3,9,"2.00","1.50","2.00","Inactivo"),
(19,"undefined","10.00",5,0,"0.00",3,10,"2.00","1.50","2.00","Inactivo"),
(20,"undefined","75.00",5,0,"0.00",4,10,"15.00","10.00","15.00","Inactivo"),
(21,"undefined","10.00",5,0,"0.00",3,11,"2.00","1.50","2.00","Inactivo"),
(22,"undefined","10.00",5,0,"0.00",1,11,"2.00","1.40","2.00","Inactivo"),
(23,"undefined","75.00",5,0,"0.00",4,12,"15.00","10.00","15.00","Inactivo"),
(24,"undefined","10.00",5,0,"0.00",3,12,"2.00","1.50","2.00","Inactivo"),
(25,"undefined","10.00",5,0,"0.00",3,13,"2.00","1.50","2.00","Activo"),
(26,"undefined","60.00",20,0,"0.00",6,13,"3.00","2.00","3.00","Activo");


SET foreign_key_checks = 1;
